# weex-vue-framework

> This package is auto-generated. For pull requests please see [src/entries/weex-framework.js](https://github.com/vuejs/vue/blob/dev/src/entries/weex-framework.js).
